function t({language:n,dictionary:o}){var a;window.Mathesar={...window.Mathesar,translations:{...(a=window.Mathesar)==null?void 0:a.translations,[n]:o}}}export{t as a};
