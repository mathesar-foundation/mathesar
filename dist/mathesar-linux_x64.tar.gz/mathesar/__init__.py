default_app_config = 'mathesar.apps.MathesarConfig'

__version__ = "0.2.0"
