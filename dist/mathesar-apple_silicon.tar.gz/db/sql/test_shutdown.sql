DROP DATABASE mathesar_testing WITH (FORCE);
