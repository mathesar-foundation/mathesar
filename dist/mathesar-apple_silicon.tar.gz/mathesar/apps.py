from django.apps import AppConfig


class MathesarConfig(AppConfig):
    """Initialization manager."""

    name = "mathesar"
