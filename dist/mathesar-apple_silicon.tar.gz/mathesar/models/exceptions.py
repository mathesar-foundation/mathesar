class NoConnectionAvailable(Exception):
    pass


class NoAdminConnectionAvailable(Exception):
    pass
