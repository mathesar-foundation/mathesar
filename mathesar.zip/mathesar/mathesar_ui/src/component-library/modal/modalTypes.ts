export type ModalCloseAction = 'button' | 'esc' | 'overlay';
