export interface TreeItem {
  [key: string]: string | unknown;
}
