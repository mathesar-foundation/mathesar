import type { IconProps } from '@mathesar-component-library-dir/icon/IconTypes';

export interface ButtonDetails {
  label: string;
  icon: IconProps;
}
