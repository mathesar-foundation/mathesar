<script>
  export let name;
</script>

<p><strong>Lorem Ipsum</strong></p>

<p>Dolor sit: <em>"{name}"</em>.</p>

<ol>
  <li>Voluptatem</li>
  <li>Quisquam</li>
</ol>
