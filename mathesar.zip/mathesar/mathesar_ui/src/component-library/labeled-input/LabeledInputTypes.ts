export type LabeledInputLayout = 'stacked' | 'inline' | 'inline-input-first';
