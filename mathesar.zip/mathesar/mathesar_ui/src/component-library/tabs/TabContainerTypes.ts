export interface Tab {
  [key: string]: unknown;
  href?: string;
  disabled?: boolean;
}
