<div class="menu">
  <slot />
</div>
