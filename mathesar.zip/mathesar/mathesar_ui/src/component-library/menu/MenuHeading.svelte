<div class="menu-heading"><slot /></div>
