<span>NULL</span>

<style>
  span {
    font-size: 90%;
    padding: 0.02em 0.3em;
    background: rgba(0, 0, 0, 0.08);
    border-radius: 3px;
    color: rgba(0, 0, 0, 0.7);
  }
</style>
