<script>
  import { Help } from '@mathesar-component-library';
</script>

<Help>
  Schemas are collections of database objects such as tables and views. They are
  best when used to organize data for a specific project.
</Help>
