class UnsupportedTypeException(Exception):
    pass


class InvalidTypeParameters(Exception):
    pass
