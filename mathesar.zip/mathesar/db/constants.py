MATHESAR_PREFIX = "mathesar_"
ID = "id"
ID_ORIGINAL = "id_original"
INFERENCE_SCHEMA = f"{MATHESAR_PREFIX}inference_schema"
COLUMN_NAME_TEMPLATE = 'Column '  # auto generated column name 'Column 1' (no undescore)
