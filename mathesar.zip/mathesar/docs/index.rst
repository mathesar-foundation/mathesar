.. Mathesar documentation master file, created by
   sphinx-quickstart on Thu Apr  8 14:08:00 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome
=======

Mathesar is an open source project that aims to make databases accessible to non-technical users, allowing users to store, manipulate, visualize, and collaborate with others on their data. Please see `the Mathesar wiki <https://wiki.mathesar.org/>`_ for more information.

*Documentation is coming soon.*
