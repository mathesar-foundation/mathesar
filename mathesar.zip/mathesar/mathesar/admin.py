from django.contrib import admin
from mathesar.models import Table, Schema, DataFile


admin.site.register(Table)
admin.site.register(Schema)
admin.site.register(DataFile)
