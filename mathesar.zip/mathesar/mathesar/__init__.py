default_app_config = 'mathesar.apps.MathesarConfig'
