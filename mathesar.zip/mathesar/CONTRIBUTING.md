Please see our [Contributing to Mathesar](https://wiki.mathesar.org/en/community/contributing) wiki page.
